import requests
import csv
import time
from datetime import datetime
import instaloader

# Your API Key (replace with actual key)
RAPIDAPI_KEY = "6e9789f6b7msh7a6699daff1441ap15e1bfjsn6ef94d2fc7dd"

# Base API URL
url = "https://instagram230.p.rapidapi.com/post/comments"

# CSV filename
csv_filename = f"instagram_comments_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"

def get_post_pk(shortcode):
    """
    Retrieves the post's primary key (post_pk) from an Instagram shortcode.
    """
    try:
        L = instaloader.Instaloader()
        post = instaloader.Post.from_shortcode(L.context, "DFMYRPRRcrq")
        print("✅ Post PK:", post.mediaid)
        return str(post.mediaid)  # Ensure it's a string
    except Exception as e:
        print(f"❌ Failed to fetch post PK: {e}")
        return None

def get_instagram_comments(post_pk, headers, csv_filename):
    """
    Scrapes comments from an Instagram post and saves them to a CSV file.
    """
    with open(csv_filename, mode="w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["Username", "Comment", "Likes", "Timestamp"])  # Header row

        next_max_id = None  # Used for pagination
        total_comments = 0  # Track how many comments we collect
        has_more_comments = True

        while has_more_comments:
            # Query parameters (include next_max_id if available)
            querystring = {"pk": post_pk}
            if next_max_id:
                querystring["max_id"] = next_max_id  # Get the next page

            try:
                # Make the API request
                response = requests.get(url, headers=headers, params=querystring)
                if response.status_code != 200:
                    print(f"❌ Error {response.status_code}: {response.text}")
                    break  # Stop if an error occurs

                comments_data = response.json()
                comments = comments_data.get("comments", [])
                
                if not comments:
                    print("✅ No more comments found.")
                    break  # Stop if no more comments

                # Save comments to CSV
                for comment in comments:
                    writer.writerow([
                        comment.get("user", {}).get("username", "N/A"),
                        comment.get("text", "N/A"),
                        comment.get("like_count", 0),
                        datetime.fromtimestamp(comment.get("created_at", 0)).strftime('%Y-%m-%d %H:%M:%S') if comment.get("created_at") else "N/A"
                    ])
                    total_comments += 1

                print(f"✅ {total_comments} comments collected so far...")

                # Get the next_max_id for pagination
                next_max_id = comments_data.get("next_max_id")  
                has_more_comments = comments_data.get("has_more_comments", False)

                if not has_more_comments:
                    print("✅ All comments retrieved.")
                    break  # Stop if no next page

                time.sleep(2)  # Delay to avoid rate limits

            except requests.exceptions.RequestException as e:
                print(f"❌ Request failed: {e}")
                break  # Stop on request exception

        print(f"✅ Scraping finished. Total comments saved: {total_comments}")

if __name__ == "__main__":
    # Replace with an Instagram post shortcode (found in the post URL)
    post_shortcode = "DHj0rw9MRsQ"  # Replace this with the actual post shortcode
    post_pk = get_post_pk(post_shortcode)

    if post_pk:
        headers = {
            "x-rapidapi-key": RAPIDAPI_KEY,
            "x-rapidapi-host": "instagram230.p.rapidapi.com"
        }
        get_instagram_comments(post_pk, headers, csv_filename)
    else:
        print("❌ Could not retrieve post PK. Exiting.")
